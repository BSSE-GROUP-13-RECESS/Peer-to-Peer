file = open('files/file1.txt', 'rb')
for chunk in file:
    print(chunk)
file.close()

import os
from ftplib import FTP, error_perm
import sys

import get_addr


def access_server():
    username = get_addr.get_wifi_ip()
    password = get_addr.get_wifi_ip()
    address = get_addr.get_wifi_ip()
    try:
        ftp = FTP(address)
        print(ftp.welcome[4:])
        try:
            ftp.login(username, password)
            logged_in = 1
            print('login successful')
        except error_perm:
            print('login failed, attempting signing up')
            ftp.putcmd('SIGNIN -u ' + username + ' -p ' + password)
            ftp.quit()
            # re-instantiate ftp
            ftp = FTP(address)
            ftp.login(username, password)
            print('sign up and log in successful.')
            logged_in = 1
        if logged_in == 1:
            return ftp
        else:
            print('Access denied!')
            exit()
    except ConnectionRefusedError:
        print('Server down or can not be reached')


def receive_file():
    ftp = access_server()
    try:
        ftp.retrbinary('RETR '+filename, save_file)
    except error_perm:
        print('Specified file does not exist')
        return False
    return True


def save_file(file_chunk):
    file.write(file_chunk)


if __name__ == "__main__":
    filename = ""
    try:
        filename = sys.argv[1]
    except IndexError:
        print("please provide file name e.g=> python client.py filename")
        exit(-1)
    filepath = 'files/'+filename
    if not os.path.isfile(filepath):
        file = open(filepath, 'wb')
        received = receive_file()
        file.close()
        if not received:
            os.remove(filepath)
        else:
            print('File received successfully')
    else:
        print('File already exists')

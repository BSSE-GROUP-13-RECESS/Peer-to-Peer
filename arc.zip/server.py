from pyftpdlib.handlers import FTPHandler as PYFTPHandler
from pyftpdlib.authorizers import DummyAuthorizer
from pyftpdlib.servers import FTPServer

import get_addr


class FTPHandler(PYFTPHandler):
    def __init__(self, conn, serve, ioloop=None):
        super().__init__(conn, serve, ioloop)
        self.user_details = None
        self.sign_in_process = 0
        self.files_in_transit = {}
        self.proto_cmds['SIGNIN'] = dict(perm=None, auth=False, arg=True,
                                         help='Syntax: SIGNIN (list all new features supported).')

    def ftp_SIGNIN(self, args):
        self.sign_in_process = 1
        arr = args.split(' ')
        credentials = ['', '']
        pos = -1
        for string in arr:
            if len(string) > 0:
                if pos > -1:
                    credentials[pos] = string
                    pos = -1
                elif string == '-u':
                    pos = 0
                elif string == '-p':
                    pos = 1
        self.authorizer.add_user(credentials[0], credentials[1], 'files', 'elradfmwMT')
        self.respond('220 sign up successful')

    # def ftp_USER(self, line):
    #     self.username = line
    #
    #     if self.authenticated:
    #         self.flush_account()
    #     if self.sign_in_process == 0:
    #         self.respond('331 Username ok, send password.')
    #     else:
    #         self.username = None
    #         self.respond("543 User does not exist.")
    #
    # def ftp_PASS(self, line):
    #     if self.authenticated:
    #         self.respond("503 User already authenticated.")
    #         return
    #     if not self.username:
    #         self.respond("503 Login with USER first.")
    #         return
    #
    #     if self.authorizer.has_user(self.username):
    #         if line == self.user_table[self.username]['pwd']:
    #             self.authorizer.remove_user(self.username)
    #             self.authorizer.add_user(self.username, line, 'files',
    #                                      'elradfmwMT')
    #             home = self.authorizer.get_home_dir(self.username)
    #             msg_login = self.authorizer.get_msg_login(self.username)
    #             self.handle_auth_success(home, line, msg_login)
    #             return
    #     self.handle_auth_failed('Wrong username or password', line)


if __name__ == "__main__":
    authorizer = DummyAuthorizer()
    handler = FTPHandler
    handler.authorizer = authorizer

    # Define a customized banner (string returned when client connects)
    handler.banner = "Hello, welcome to the ftp server"

    server = FTPServer((get_addr.get_wifi_ip(), 21), FTPHandler)
    server.serve_forever()
